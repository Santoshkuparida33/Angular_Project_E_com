﻿namespace E_Com_Api.Model
{
    public class Order
    {

            public int orderId { get; set; }
            public string email { get; set; }
            public string address { get; set; }
            public string contact { get; set; }
            public decimal totalPrice { get; set; }
            public int userId { get; set; }
        public int ProductId { get; set; }
        public string name { get; set; }

    }
}
