﻿namespace E_Com_Api.Model
{
    public class Seller_signup
    {
        public int? Id { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? phoneNumber { get; set; }
        public string? Password { get; set; }
        public string? Address { get; set; }
    }
}
