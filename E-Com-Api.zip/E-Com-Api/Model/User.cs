﻿namespace E_Com_Api.Model
{
    public class User
    {
        public int UserId { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string password { get; set; }
    }
}
