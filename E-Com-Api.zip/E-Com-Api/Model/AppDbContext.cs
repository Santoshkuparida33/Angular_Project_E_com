﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace E_Com_Api.Model
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<Seller_signup> Sellers { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Order { get; set; }
        public DbSet<User> User { get; set; }

        public int InsertSeller(Seller_signup seller)
        {
            var idParam = new SqlParameter("@Id", SqlDbType.Int) { Direction = ParameterDirection.Output };

            Database.ExecuteSqlRaw("EXEC Sp_InsertSeller @Name, @Email, @Password, @PhoneNumber, @Address, @Id OUT",
                new SqlParameter("@Name", seller.Name),
                new SqlParameter("@Email", seller.Email),
                new SqlParameter("@Password", seller.Password),
                new SqlParameter("@PhoneNumber", (object)seller.phoneNumber ?? DBNull.Value),
                new SqlParameter("@Address", (object)seller.Address ?? DBNull.Value),
                idParam);

            return (int)idParam.Value;
        }

        public IEnumerable<Seller_signup> GetAllSellers()
        {
            return Sellers.FromSqlRaw<Seller_signup>("EXEC GetAllSellers").ToList();
        }

        public async Task<int> InsertProduct(Product product)
        {
            var productIdParam = new SqlParameter("@ProductId", SqlDbType.Int) { Direction = ParameterDirection.Output };

            var parameters = new[]
            {
                new SqlParameter("@Name", product.Name),
                new SqlParameter("@Price", product.Price),
                new SqlParameter("@Color", (object)product.Color ?? DBNull.Value),
                new SqlParameter("@Category", (object)product.Category ?? DBNull.Value),
                new SqlParameter("@Description", (object)product.Description ?? DBNull.Value),
                new SqlParameter("@ImageUrl", (object)product.ImageUrl ?? DBNull.Value),
                new SqlParameter("@SellerId", (object)product.SellerId ?? DBNull.Value),
                productIdParam
            };

            await Database.ExecuteSqlRawAsync("EXEC AddProduct @Name, @Price, @Color, @Category, @Description, @ImageUrl,@SellerId, @ProductId OUTPUT", parameters);

            return (int)productIdParam.Value;
        }

        public async Task<int> EditProduct(Product product)
        {
            var editedProductIdParam = new SqlParameter("@EditedProductId", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };

            var parameters = new[]
            {
        new SqlParameter("@ProductId", product.Id),
        new SqlParameter("@Name", product.Name),
        new SqlParameter("@Price", product.Price),
        new SqlParameter("@Color", (object)product.Color ?? DBNull.Value),
        new SqlParameter("@Category", (object)product.Category ?? DBNull.Value),
        new SqlParameter("@Description", (object)product.Description ?? DBNull.Value),
        new SqlParameter("@ImageUrl", (object)product.ImageUrl ?? DBNull.Value),
        editedProductIdParam
    };

            await Database.ExecuteSqlRawAsync(
                "EXEC EditProduct @ProductId, @Name, @Price, @Color, @Category, @Description, @ImageUrl, @EditedProductId OUTPUT",
                parameters
            );

            return (int)editedProductIdParam.Value;
        }
        public async Task<bool> DeleteProduct(int productId)
        {
            var productIdParam = new SqlParameter("@ProductId", productId);

            var result = await Database.ExecuteSqlRawAsync("EXEC DeleteProduct @ProductId", productIdParam);

            return result > 0;

        }

        public async Task<List<Product>> ListProducts()
        {
            return await Products.FromSqlRaw("EXEC ListProducts").ToListAsync();
        }
        public async Task<List<Product>> ListProductsBySellerId(int sellerId)
        {
            var products = new List<Product>();
            var connectionString = Database.GetDbConnection().ConnectionString;

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    using (var command = new SqlCommand("ListProductsBySellerId", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@SellerId", sellerId));

                        connection.Open();

                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                products.Add(new Product
                                {
                                    Id = reader.GetInt32(reader.GetOrdinal("Id")),
                                    Name = reader.GetString(reader.GetOrdinal("Name")),
                                    Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                                    Category = reader.GetString(reader.GetOrdinal("Category")),
                                    Color = reader.IsDBNull(reader.GetOrdinal("Color")) ? null : reader.GetString(reader.GetOrdinal("Color")),
                                    Description = reader.IsDBNull(reader.GetOrdinal("Description")) ? null : reader.GetString(reader.GetOrdinal("Description")),
                                    ImageUrl = reader.IsDBNull(reader.GetOrdinal("ImageUrl")) ? null : reader.GetString(reader.GetOrdinal("ImageUrl")),
                                });
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                // Handle exception
                throw;
            }

            return products;
        }


        public async Task<Product> GetProductById(int id)
        {
            Product product = null;
            var connectionString = Database.GetDbConnection().ConnectionString;

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    using (var command = new SqlCommand("GetProductById", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@Id", id));

                        connection.Open();

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            if (reader.Read())
                            {
                                product = new Product
                                {
                                    Id = reader.GetInt32(reader.GetOrdinal("Id")),
                                    Name = reader.GetString(reader.GetOrdinal("Name")),
                                    Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                                    Category = reader.GetString(reader.GetOrdinal("Category")),
                                    Color = reader.IsDBNull(reader.GetOrdinal("Color")) ? null : reader.GetString(reader.GetOrdinal("Color")),
                                    Description = reader.IsDBNull(reader.GetOrdinal("Description")) ? null : reader.GetString(reader.GetOrdinal("Description")),
                                    ImageUrl = reader.IsDBNull(reader.GetOrdinal("ImageUrl")) ? null : reader.GetString(reader.GetOrdinal("ImageUrl")),
                                };
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                // Handle exception
                throw;
            }

            return product;
        }
        //public async Task<Product> SearchProductsByName(string name)
        //{
        //    var productnameParam = new SqlParameter("@ProductName", name);
        //    var products = await Products.FromSqlRaw("EXEC SearchProductsByName @ProductName", productnameParam).ToListAsync();

        //    return products.FirstOrDefault();
        //}
        public async Task<List<Product>> SearchProductsByName(string name)
        {
            var products = new List<Product>();
            var connectionString = Database.GetDbConnection().ConnectionString;

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    using (var command = new SqlCommand("SearchProductsByName", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@ProductName", name));

                        connection.Open();

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            while (reader.Read())
                            {
                                var product = new Product
                                {
                                    Id = reader.GetInt32(reader.GetOrdinal("Id")),
                                    Name = reader.GetString(reader.GetOrdinal("Name")),
                                    Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                                    Category = reader.GetString(reader.GetOrdinal("Category")),
                                    Color = reader.IsDBNull(reader.GetOrdinal("Color")) ? null : reader.GetString(reader.GetOrdinal("Color")),
                                    Description = reader.IsDBNull(reader.GetOrdinal("Description")) ? null : reader.GetString(reader.GetOrdinal("Description")),
                                    ImageUrl = reader.IsDBNull(reader.GetOrdinal("ImageUrl")) ? null : reader.GetString(reader.GetOrdinal("ImageUrl")),
                                };
                                products.Add(product);
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                // Handle exception
                throw;
            }

            return products;
        }
        public int InsertUser(User user)
        {
            var idParam = new SqlParameter("@NewUserId", SqlDbType.Int) { Direction = ParameterDirection.Output };

            Database.ExecuteSqlRaw("EXEC sp_InsertUser @UserName, @Email, @Password, @NewUserId OUT",
                new SqlParameter("@UserName", user.name),
                new SqlParameter("@Email", user.email),
                new SqlParameter("@Password", user.password),
                idParam);

            return (int)idParam.Value;
        }

        public async Task<List<User>> LoginUser(string email, string password)
        {
            var users = new List<User>();

            var connectionString = Database.GetDbConnection().ConnectionString;

            using (var connection = new SqlConnection(connectionString))
            {
                using (var command = new SqlCommand("sp_UserLogin", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@Password", password);

                    await connection.OpenAsync();

                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            var user = new User
                            {
                                UserId = reader.GetInt32(reader.GetOrdinal("UserId")),
                                name = reader.GetString(reader.GetOrdinal("UserName")),
                                email = reader.GetString(reader.GetOrdinal("Email"))
                            };

                            users.Add(user);
                        }
                    }
                }
            }

            return users;
        }
        public async Task<List<Seller_signup>> SellerLogin(string email, string password)
        {
            var sellers = new List<Seller_signup>();

            var connectionString = Database.GetDbConnection().ConnectionString;

            using (var connection = new SqlConnection(connectionString))
            {
                using (var command = new SqlCommand("sp_SellerLogin", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@Password", password);

                    await connection.OpenAsync();

                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            var seller = new Seller_signup
                            {
                                Id = reader.GetInt32(reader.GetOrdinal("Id")),
                                Name = reader.GetString(reader.GetOrdinal("Name")),
                                Email = reader.GetString(reader.GetOrdinal("Email")),
                            };

                            sellers.Add(seller);
                        }
                    }
                }
            }

            return sellers;
        }

        public async Task<int> InsertCart(Cart cart)
        {
            var cartIdParam = new SqlParameter("@CartId", SqlDbType.Int) { Direction = ParameterDirection.Output };

            var parameters = new[]
            {
        new SqlParameter("@Name", cart.Name),
        new SqlParameter("@Price", cart.Price),
        new SqlParameter("@Category", cart.Category),
        new SqlParameter("@Color", (object)cart.Color ?? DBNull.Value),
        new SqlParameter("@Description", (object)cart.Description ?? DBNull.Value),
        new SqlParameter("@ImageUrl", (object)cart.ImageUrl ?? DBNull.Value),
        new SqlParameter("@Quantity", cart.Quantity),
        new SqlParameter("@UserId", cart.UserId),
        new SqlParameter("@ProductId", cart.ProductId),
        cartIdParam
        };

            await Database.ExecuteSqlRawAsync("EXEC AddCart @Name, @Price, @Category, @Color, @Description, @ImageUrl, @Quantity, @UserId, @ProductId, @CartId OUTPUT", parameters);

            return (int)cartIdParam.Value;
        }
        public IEnumerable<Cart> GetCartByUserId(int userId)
        {
            var cartItems = new List<Cart>();
            var connectionString = Database.GetDbConnection().ConnectionString;

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    using (var command = new SqlCommand("GetCartByUserId", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@UserId", userId));

                        connection.Open();

                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                cartItems.Add(new Cart
                                {
                                    CartId = reader.GetInt32(reader.GetOrdinal("CartId")),
                                    Name = reader.GetString(reader.GetOrdinal("Name")),
                                    Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                                    Category = reader.GetString(reader.GetOrdinal("Category")),
                                    Color = reader.IsDBNull(reader.GetOrdinal("Color")) ? null : reader.GetString(reader.GetOrdinal("Color")),
                                    Description = reader.IsDBNull(reader.GetOrdinal("Description")) ? null : reader.GetString(reader.GetOrdinal("Description")),
                                    ImageUrl = reader.IsDBNull(reader.GetOrdinal("ImageUrl")) ? null : reader.GetString(reader.GetOrdinal("ImageUrl")),
                                    Quantity = reader.GetInt32(reader.GetOrdinal("Quantity")),
                                    UserId = reader.GetInt32(reader.GetOrdinal("UserId")),
                                    ProductId = reader.GetInt32(reader.GetOrdinal("ProductId"))
                                });
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
              
                throw;
            }

            return cartItems;
        }
        public async Task<bool> DeleteCartItem(int cartId)
        {
            var cartIdParam = new SqlParameter("@CartId", cartId);

            var result = await Database.ExecuteSqlRawAsync("EXEC DeleteCartItem @CartId", cartIdParam);

            return result > 0;
        }

        public async Task<int> InsertOrder(Order order)
        {
            var orderIdParam = new SqlParameter("@OrderID", SqlDbType.Int) { Direction = ParameterDirection.Output };

            var parameters = new[]
            {
                new SqlParameter("@Email", order.email),
                new SqlParameter("@Address", order.address),
                new SqlParameter("@Contact", order.contact),
                new SqlParameter("@TotalAmount", order.totalPrice),
                new SqlParameter("@UserID", order.userId),
                new SqlParameter("@ProductID", order.ProductId),
                new SqlParameter("@Name", order.name),
                orderIdParam
            };

            await Database.ExecuteSqlRawAsync("EXEC InsertOrder @Email, @Address, @Contact, @TotalAmount, @UserID,@ProductID,@Name, @OrderID OUTPUT", parameters);

            return (int)orderIdParam.Value;
        }
        public async Task<List<Order>> GetOrdersByUserIdAsync(int userId)
        {
            var orders = new List<Order>();

            var connectionString = Database.GetDbConnection().ConnectionString;

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    using (var command = new SqlCommand("GetOrdersByUserID", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@UserID", userId);

                        await connection.OpenAsync();

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                var order = new Order
                                {
                                    orderId = reader.GetInt32(reader.GetOrdinal("OrderId")),
                                    email = reader.GetString(reader.GetOrdinal("Email")),
                                    address = reader.GetString(reader.GetOrdinal("Address")),
                                    contact = reader.GetString(reader.GetOrdinal("Contact")),
                                    totalPrice = reader.GetDecimal(reader.GetOrdinal("TotalAmount")),

                                    userId = reader.GetInt32(reader.GetOrdinal("UserId"))
                                };

                                orders.Add(order);
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                // Log the exception or handle it as needed
                // Example: _logger.LogError(ex, "Error fetching orders for user ID {UserId}", userId);
                throw new Exception("An error occurred while retrieving orders.", ex);
            }

            return orders;
        }
        public IEnumerable<Cart> GetCart_ByUserId(int userId)
        {
            var cartItems = new List<Cart>();
            var connectionString = Database.GetDbConnection().ConnectionString;

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    using (var command = new SqlCommand("GetCartByUserId", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@UserId", userId));

                        connection.Open();

                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                cartItems.Add(new Cart
                                {
                                    CartId = reader.GetInt32(reader.GetOrdinal("CartId")),
                                    Name = reader.GetString(reader.GetOrdinal("Name")),
                                    Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                                    Category = reader.GetString(reader.GetOrdinal("Category")),
                                    Color = reader.IsDBNull(reader.GetOrdinal("Color")) ? null : reader.GetString(reader.GetOrdinal("Color")),
                                    Description = reader.IsDBNull(reader.GetOrdinal("Description")) ? null : reader.GetString(reader.GetOrdinal("Description")),
                                    ImageUrl = reader.IsDBNull(reader.GetOrdinal("ImageUrl")) ? null : reader.GetString(reader.GetOrdinal("ImageUrl")),
                                    Quantity = reader.GetInt32(reader.GetOrdinal("Quantity")),
                                    UserId = reader.GetInt32(reader.GetOrdinal("UserId")),
                                    ProductId = reader.GetInt32(reader.GetOrdinal("ProductId"))
                                });
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {

                throw;
            }

            return cartItems;
        }
        public async Task<bool> DeleteCartByUserId(int userId)
        {
            var cartIdParam = new SqlParameter("@UserId", userId);

            var result = await Database.ExecuteSqlRawAsync("EXEC DeleteCartByUserId @UserId", cartIdParam);

            return result > 0;
        }
        public async Task<bool> DeleteOrderByIdAsync(int orderId)
        {
            var orderIdParam = new SqlParameter("@OrderID", orderId);

            var result = await Database.ExecuteSqlRawAsync("EXEC DeleteOrder @OrderID", orderIdParam);

            return result > 0;
        }

    }
}
