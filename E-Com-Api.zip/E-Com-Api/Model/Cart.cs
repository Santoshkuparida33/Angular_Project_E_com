﻿namespace E_Com_Api.Model
{
    public class Cart
    {
        public int CartId { get; set; }

        public string Name { get; set; }

        public decimal Price { get; set; }

        public string Category { get; set; }

        public string Color { get; set; }

        public string Description { get; set; }

        public string ImageUrl { get; set; }

        public int Quantity { get; set; }

        public int UserId { get; set; }

        public int ProductId { get; set; }
    }
}
