﻿using E_Com_Api.Model;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace E_Com_Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ProductController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        [Route("AddProduct")]
        public async Task<ActionResult<int>> AddProduct(Product product)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var productId = await _context.InsertProduct(product);

            return Ok(new { Message = "Product added successfully", ProductId = productId });
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> EditProduct(int id, Product product)
        {
            if (id != product.Id)
            {
                return BadRequest();
            }

            var result = await _context.EditProduct(product);

            if (result > 0)
            {
                return Ok(new { Message = "Product updated successfully" });
            }
            else
            {
                return NotFound(new { Message = "Product not found" });
            }
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<Product>> GetProductById(int id)
        {
            var product = await _context.GetProductById(id);

            if (product == null)
            {
                return NotFound(new { Message = "Product not found" });
            }

            return Ok(product);
        }
        [HttpGet("search")]
        public async Task<ActionResult<Product>> SearchProductsByName(string name)
        {
            var product = await _context.SearchProductsByName(name);

            if (product == null)
            {
                return NotFound(new { Message = "Product not found" });
            }

            return Ok(product);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteProduct(int id)
        {
            var result = await _context.DeleteProduct(id);

            if (result)
            {
                return Ok(new { Message = "Product deleted successfully" });
            }
            else
            {
                return NotFound(new { Message = "Product not found" });
            }
        }

        [HttpGet]
        public async Task<ActionResult<List<Product>>> ListProducts()
        {
            var products = await _context.ListProducts();
            return Ok(products);
        }
        [HttpGet("ListProductsBySellerId/{sellerId}")]
        public async Task<ActionResult<List<Product>>> ListProductsBySellerId(int sellerId)
        {
            var products = await _context.ListProductsBySellerId(sellerId);
            return Ok(products);
        }
        [HttpPost]
        [Route("AddOrder")]
        public async Task<ActionResult<int>> AddOrder(Order order)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var orderId = await _context.InsertOrder(order);

            return Ok(new { Message = "Order added successfully", OrderId = orderId });
        }


    }
}
