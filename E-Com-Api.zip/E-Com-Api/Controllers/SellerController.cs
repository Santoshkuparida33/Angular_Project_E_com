﻿using E_Com_Api.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace E_Com_Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SellerController : ControllerBase
    {
        private AppDbContext _context;
        public SellerController(AppDbContext context)
        {
            _context = context;
        }
        [HttpPost]
        public ActionResult<Seller_signup> PostSeller(Seller_signup sellerAccount)
        {
            var id = _context.InsertSeller(sellerAccount);

            return Ok(id);
        }
        [HttpGet]
        public ActionResult<IEnumerable<Seller_signup>> GetAllSellers()
        {
            try
            {
                var sellers = _context.GetAllSellers();
                return Ok(sellers);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [HttpGet("login")]
        public async Task<ActionResult<Seller_signup>> SellerLogin(string email, string password)
        {
            var sellers = await _context.SellerLogin(email, password);

            if (sellers == null || sellers.Count == 0)
            {
                return Unauthorized("Invalid credentials");
            }

            var seller = sellers.FirstOrDefault();
            return Ok(seller);
        }
    }
}
