﻿using E_Com_Api.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace E_Com_Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private AppDbContext _context;
        public UserController(AppDbContext context)
        {
            _context = context;
        }
        [HttpPost]
        public ActionResult<User> PostUser(User UserData)
        {
            var id = _context.InsertUser(UserData);

            return Ok(id);
        }
        [HttpGet("login")]
        public async Task<ActionResult<User>> Userlogin(string email, string password)
        {
            var users = await _context.LoginUser(email, password);

            if (users == null || users.Count == 0)
            {
                return Unauthorized("Invalid credentials");
            }
            var user = users.FirstOrDefault();
            return Ok(user);
        }
        [HttpPost]
        [Route("AddCart")]
        public async Task<ActionResult<int>> AddCart(Cart cart)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var cartId = await _context.InsertCart(cart);

            return Ok(new { Message = "Cart item added successfully", CartId = cartId });
        }
        [HttpGet("{userId}")]
        public ActionResult<IEnumerable<Cart>> GetCartByUserId(int userId)
        {
            var cartItems = _context.GetCart_ByUserId(userId);
            if (cartItems == null)
            {
                return NotFound();
            }

            return Ok(cartItems);
        }
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteCartItem(int id)
        {
            var result = await _context.DeleteCartItem(id);

            if (result)
            {
                return Ok(new { Message = "Cart item deleted successfully" });
            }
            else
            {
                return NotFound(new { Message = "Cart item not found" });
            }
        }
        [HttpGet("GetOrdersByUserId/{userId}")]
        public async Task<ActionResult<List<Order>>> GetOrdersByUserId(int userId)
        {
            try
            {
                var orders = await _context.GetOrdersByUserIdAsync(userId);

                if (orders == null || !orders.Any())
                {
                    return NotFound(new { Message = "Orders not found" });
                }

                return Ok(orders);
            }
            catch (Exception ex)
            {
                // Log the exception (optional)
                // Example: _logger.LogError(ex, "Error fetching orders for user ID {UserId}", userId);

                return StatusCode(500, new { Message = "An error occurred while retrieving orders" });
            }
        }
        [HttpDelete("DeleteCartByUserId/{userId}")]
        public async Task<ActionResult> DeleteCartByUserId(int userId)
        {
            var result = await _context.DeleteCartByUserId(userId);

            if (result)
            {
                return NotFound(new { Message = "Cart item not found" });
            }
            else
            {
                return Ok(new { Message = "Cart item deleted successfully" });
            }
        }
        [HttpDelete("DeleteOrderById/{orderId}")]
        public async Task<ActionResult> DeleteOrderById(int orderId)
        {
            var result = await _context.DeleteOrderByIdAsync(orderId);

            if (!result)
            {
                return Ok(new { Message = "Order deleted successfully" });
            }
            else
            {
                return NotFound(new { Message = "Order not found" });
            }
        }

    }
}
